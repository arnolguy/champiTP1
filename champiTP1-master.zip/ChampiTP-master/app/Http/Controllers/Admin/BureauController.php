<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Repositories\Admin\MemberRepository;
use App\Repositories\Admin\RoleRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BureauController extends Controller
{
    /**
     * @var RoleRepository
     */
    private $roleRepository;
    /**
     * @var MemberRepository
     */
    private $memberRepository;

    public function __construct(RoleRepository $roleRepository, MemberRepository $memberRepository)
    {
        $this->roleRepository = $roleRepository;
        $this->memberRepository = $memberRepository;
    }

    public function index()
    {
        $roles = $this->roleRepository->getAll();
        $members = $this->memberRepository->getAll();
        return view('Admin.bureau.index', compact('roles', 'members'));
    }

    public function store(Request $request)
    {
        foreach ($request->input() as $role_id => $member_id) {
            if ($member_id && is_numeric($role_id)) {
                DB::table('members')->where('id', $member_id)->update(['role_id' => $role_id]);
            }
        }
        return redirect()->route('bureau.index')->with('success', 'The office members have been updated!');
    }
}
