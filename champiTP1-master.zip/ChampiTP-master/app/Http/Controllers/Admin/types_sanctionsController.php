<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Admin\Type_santionRequest;
use App\Repositories\Admin\Type_santionRepository;
use App\Http\Controllers\Controller;

class types_sanctionsController extends Controller
{
    /**
     * @var Type_santionRepository
     */
    private $type_santionRepository;

    public function __construct(Type_santionRepository $type_santionRepository)
    {
        $this->type_santionRepository = $type_santionRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $types_santions = $this->type_santionRepository->getAll();
        return view('Admin.types_santions.index', compact('types_santions'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.types_santions.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Type_santionRequest $request)
    {
         if ($this->type_santionRepository->store($request->input())) {
            return redirect()->route('type_santion.index')->with('success', 'New Type_santion created successfully!');
        }else {
            return back()->with('error', 'An error has occurred. Please try again !');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $type_santion = $this->type_santionRepository->getById($id);
        return view('admin.types_santions.edit', compact('type_santion'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Type_santionRequest $request, $id)
    {
        if($this->type_santionRepository->update($id, $request->input())) {
            return redirect()->route('type_santion.index')->with('success', 'Type_santion Update Successfully');
        }else {
            return back()->with('error', 'An error has occurred. Please try again !');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($this->type_santionRepository->destroy($id)) {
            return redirect()->route('type_santion.index')->with('success', 'Type_santion delete successfully!');
        }else {
            return back()->with('error', 'An error has occurred. Please try again !');
        }
    }
}
