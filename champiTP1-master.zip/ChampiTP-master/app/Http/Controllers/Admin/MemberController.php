<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Admin\MemberRequest;
use App\Repositories\Admin\MemberRepository;
use App\Http\Controllers\Controller;

class MemberController extends Controller
{
    /**
     * @var MemberRepository
     */
    private $memberRepository;

    public function __construct(MemberRepository $memberRepository)
    {

        $this->memberRepository = $memberRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $members = $this->memberRepository->getAll();
        return view('Admin.members.index', compact('members'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Admin.members.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(MemberRequest $request)
    {
        $link = false;
        if ($request->file('image')) {
            $link = $this->memberRepository->saveImage($request->file('image'));
        }
        ($link) ? $data = array_merge($request->input(), ['image' => $link, 'password' => bcrypt('ajsd'), 'role_id' => 1]) :
            $data = array_merge($request->input(), ['password' => bcrypt('ajsd'), 'role_id' => 1]);

        $data['birthday'] = $this->getDate($request->input('birthday'));

        if ($this->memberRepository->store($data)) {
            return redirect()->route('member.index')->with('success', 'Member created successfully!');
        } else {
            return back()->with('error', 'An error has occurred. Please try again !');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $member = $this->memberRepository->getById($id);
        return view('Admin.members.edit', compact('member'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(MemberRequest $request, $id)
    {
        $link = false;
        if ($request->file('image')) {
            $link = $this->memberRepository->saveImage($request->file('image'));
        }
        ($link) ? $data = array_merge($request->input(), ['image' => $link]) : $data = $request->input();
        if ($this->memberRepository->update($id, $data)) {
            return redirect()->route('member.index')->with('success', 'Member update successfully!');
        } else {
            return back()->with('error', 'An error has occurred. Please try again !');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($this->memberRepository->destroy($id)) {
            return redirect()->route('member.index')->with('success', 'Member delete successfully!');
        } else {
            return back()->with('error', 'An error has occurred. Please try again !');
        }

    }
}
