<?php
/**
 * Created by PhpStorm.
 * User: trendvesterpc
 * Date: 2019-03-25
 * Time: 05:14
 */

namespace App\Http\Requests;


use Illuminate\Foundation\Http\FormRequest;

abstract class Request extends FormRequest
{

}