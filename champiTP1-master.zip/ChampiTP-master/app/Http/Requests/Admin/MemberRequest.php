<?php
/**
 * Created by PhpStorm.
 * User: trendvesterpc
 * Date: 2019-03-25
 * Time: 05:07
 */

namespace App\Http\Requests\Admin;


use App\Http\Requests\Request;

class MemberRequest extends Request
{
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'firstName' => 'required|min:2|max:100',
            'lastName' => 'required|min:2|max:100',
            'cni' => 'required|min:9',
            'birthday' => 'required|date',
            'sex' => 'required',
            'phoneNumber1' => 'required|min:9|max:14',
            'image' => 'image'
        ];
    }
}