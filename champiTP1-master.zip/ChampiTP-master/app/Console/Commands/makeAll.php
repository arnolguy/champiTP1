<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Str;

class makeAll extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'makeAll:mcr {table}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Make Model, Resource Controller, Seeder, and Request by the table name';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $argument = $this->argument('table');
        $modelName = ucfirst($argument);
        $migrationName = 'create_' . $argument . '_table';
        $seederName = $modelName . 'TableSeeder';
        $controllerName = 'Admin/' . $modelName . 'Controller';
        $requestName = 'Admin/' . $modelName . 'Request';
        $modelName = 'Models/' . $modelName;

        $this->callSilent('make:migration', [
            'name' => $migrationName, '--create' => Str::plural($argument)
        ]);
        $this->callSilent('make:seeder', ['name' => $seederName]);
        $this->callSilent('make:model', ['name' => $modelName]);
        $this->callSilent('make:request', ['name' => $requestName]);
        $this->callSilent('make:controller', [
            'name' => $controllerName, '--resource' => true
        ]);
    }
}
