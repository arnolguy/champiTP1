<?php
/**
 * Created by PhpStorm.
 * User: trendvesterpc
 * Date: 2019-03-25
 * Time: 05:01
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    protected $table = 'members';

    protected $fillable = [
        'firstName', 'lastName', 'email',
        'cni', 'activity', 'birthday', 'sex',
        'phoneNumber1', 'phoneNumber2',
        'note', 'image', 'password'
    ];

    public function role()
    {
        return $this->belongsTo('App\Models\Role');
    }
}