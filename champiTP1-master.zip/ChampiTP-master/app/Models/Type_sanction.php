<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Type_sanction extends Model
{
    protected $table = 'types_sanctions';
    protected $fillable = ['nom', 'montant'];
    public $timestamps = false;

    // public function member()
    // {
    //     return $this->hasMany('App\Models\Member');
    // }
}
