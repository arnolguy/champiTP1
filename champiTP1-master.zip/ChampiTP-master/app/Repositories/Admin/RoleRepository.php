<?php
/**
 * Created by PhpStorm.
 * User: trendvesterpc
 * Date: 2019-03-27
 * Time: 14:58
 */

namespace App\Repositories\Admin;


use App\Models\Role;
use App\Repositories\ResourceRepository;

class RoleRepository extends ResourceRepository
{
    public function __construct(Role $role)
    {
        $this->model = $role;
    }
}