<?php
/**
 * Created by PhpStorm.
 * User: trendvesterpc
 * Date: 2019-03-25
 * Time: 05:17
 */

namespace App\Repositories\Admin;


use App\Models\Member;
use App\Repositories\ResourceRepository;
use Carbon\Carbon;
use Illuminate\Support\Str;

class MemberRepository extends ResourceRepository
{
    public function __construct(Member $member)
    {
        $this->model = $member;
        $this->confPath = 'image.path';
    }
}