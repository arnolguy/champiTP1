<?php
/**
 * Created by PhpStorm.
 * User: trendvesterpc
 * Date: 2019-03-25
 * Time: 05:17
 */

namespace App\Repositories\Admin;


use App\Models\Type_sanction;
use App\Repositories\ResourceRepository;
use Carbon\Carbon;
use Illuminate\Support\Str;

class type_santionRepository extends ResourceRepository
{
    public function __construct(Type_sanction $type_santion)
    {
        $this->model = $type_santion;
    }
}