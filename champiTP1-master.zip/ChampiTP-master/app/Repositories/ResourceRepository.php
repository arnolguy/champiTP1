<?php
/**
 * Created by PhpStorm.
 * User: trendvesterpc
 * Date: 2019-03-25
 * Time: 05:20
 */

namespace App\Repositories;


use Carbon\Carbon;
use Illuminate\Support\Str;

class ResourceRepository
{
    /**
     * @var
     */
    protected $model;
    protected $confPath = 'image.path';

    public function getAll()
    {
        return $this->model->all();
    }
    /**
     * @param $n
     * @return mixed
     */
    public function getPaginate($n)
    {
        return $this->model->paginate($n);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function getById($id)
    {
        return $this->model->findOrFail($id);
    }

    /**
     * @param array $data
     * @return mixed
     */
    public function store(Array $data)
    {
        return $this->model->create($data);
    }

    /**
     * @param $id
     * @param array $data
     * @return mixed|void
     */
    public function update($id, Array $data)
    {
        return $this->getById($id)->update($data);
    }

    /**
     * @param $id
     * @return mixed|void
     */
    public function destroy($id)
    {
        return $this->getById($id)->delete();
    }

    /**
     * @param $image
     * @param $firstName
     * @param $lastName
     * @return bool
     */
    public function saveImage($image)
    {
        if ($image->isValid()) {
            $date = Carbon::createFromDate();
            $chemin = config($this->confPath);
            $extention = $image->getClientOriginalExtension();

            do {
                $nom = Str::random(5) . '.' . $extention;
            } while (file_exists($chemin . DIRECTORY_SEPARATOR . $nom));

            if ($image->move($chemin, $nom)) {
                return $nom;
            }
        }
        return false;
    }
}