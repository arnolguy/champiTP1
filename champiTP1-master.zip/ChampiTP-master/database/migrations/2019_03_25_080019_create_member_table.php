<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMemberTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('members', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('role_id')->unsigned()->default(1);
            $table->string('firstName');
            $table->string('lastName');
            $table->string('cni')->unique();
            $table->dateTime('birthday');
            $table->char('sex', 1);
            $table->string('phoneNumber1', 14)->unique();
            $table->string('phoneNumber2', 14)->unique()->nullable(true);
            $table->string('activity')->nullable(true);
            $table->string('email')->unique()->nullable(true);
            $table->longText('note')->nullable(true);
            $table->string('image')->nullable(true);
            $table->string('password')->default(bcrypt('ajsd'));
            $table->timestamps();

            $table->foreign('role_id')->references('id')->on('roles');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('members', function (Blueprint $table) {
            $table->dropForeign('members_role_id_foreign');
        });
        Schema::dropIfExists('members');
    }
}
