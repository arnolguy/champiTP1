<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('roles')->delete();
        $positions = [
            'Membre', 'Président', 'Vis Président', 'Trésorier', 'Censeur', 'Vis Censeur',
            'Sécretaire', 'Commissaire aux Comptes', 'Porte Parole'
        ];

        for ($i = 0; $i < count($positions); ++$i) {
            DB::table('roles')->insert([
                'name' => $positions[$i],
                'note' => 'Note ' . $positions[$i]
            ]);
        }
    }
}
