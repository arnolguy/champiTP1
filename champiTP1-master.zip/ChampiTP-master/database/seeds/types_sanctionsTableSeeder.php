<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class types_sanctionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('types_sanctions')->delete();
        $positions = [
            'Retard', 'Absent', 'Tenue non conforme', 'Cahier de note', 'Bible', 'Sonnerie de telephone',
            'Sortie sans permission'
        ];
        for ($i = 0; $i < count($positions); ++$i) {
        	DB::table('types_sanctions')->insert([
        		'nom' => $positions[$i],
        		'montant' => Str::random(10)
        	]);
        }
    }
}
