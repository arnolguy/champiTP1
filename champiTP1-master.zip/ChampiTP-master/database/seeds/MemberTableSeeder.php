<?php

use Carbon\Carbon;
use Faker\Provider\PhoneNumber;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class MemberTableSeeder extends Seeder
{

    public function randDate()
    {
        return Carbon::createFromDate(rand(1986, 1992), rand(1, 12), rand(1, 28));
    }

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('members')->delete();
        for ($i = 0; $i < 20; $i++) {
            $orange = '69';
            $mtn = '67';
            for ($j = 0; $j < 7; $j++) {
                $orange .= mt_rand(0, 9);
                $mtn .= mt_rand(0, 9);
            }
            $date = $this->randDate();
            DB::table('members')->insert([
                'role_id' => 1,
                'firstName' => Str::random(10),
                'lastName' => Str::random(10),
                'email' => Str::random(10) . '@gmail.com',
                'cni' => Str::random(10),
                'activity' => PhoneNumber::randomNumber(9, true),
                'birthDay' => $date,
                'sex' => (rand(0, 1) == 1) ? 'F' : 'M',
                'phoneNumber1' => $orange,
                'phoneNumber2' => $mtn,
                'note' => 'lorem ipsum ...',
                'password' => bcrypt('ajsd')
            ]);
        }
    }
}
