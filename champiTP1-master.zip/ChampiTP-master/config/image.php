<?php
return [
    'path' => 'images' . DIRECTORY_SEPARATOR . 'members'
];